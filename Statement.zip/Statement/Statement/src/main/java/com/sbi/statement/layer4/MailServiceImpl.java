package com.sbi.statement.layer4;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.itextpdf.text.DocumentException;
import com.sbi.statement.layer2.Constants;

import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {
	
	@Autowired
	StatementPDFView pdfView;
	
	@Override			
	public void sendMail(String info, String emailTo, String generatePdfPath, LocalDate fromDate, LocalDate toDate) throws DocumentException { 

		String fromEmail="nischaldutt01@gmail.com";
		String password="nzuwvogvpltleyrb";

		String host="smtp.gmail.com";
		Properties props = new Properties(); //key + value
		props.put("mail.smtp.auth","true");
		props.put("mail.smtp.starttls.enable","true");
		props.put("mail.smtp.host",host);
		props.put("mail.smtp.port","587");

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
	    	protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		});
		
		try
		{
			MimeMessage message= new MimeMessage(session);//gmail+myEmail+password token
			message.setFrom(new InternetAddress(fromEmail));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailTo));
			message.setSubject("Message From SBI");
			message.setText(info);
			
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			// creates a new e-mail message
			messageBodyPart.setContent(Constants.EMAIL_TEMPLATE, "text/html");
			
			Multipart multipart = new MimeMultipart();
	        multipart.addBodyPart(messageBodyPart);
	        
	        File f = new File(generatePdfPath);
	        
	        // adds attachments
	        if (generatePdfPath != null) {
	              MimeBodyPart attachPart = new MimeBodyPart();
	              try {
	            	  if(f.exists())
	            	  {
	            		  attachPart.attachFile(generatePdfPath);
	            	  }
	            	  else
	            	  {
	            		  generatePdfPath = pdfView.transactionList(emailTo, fromDate, toDate) ;
	            		  attachPart.attachFile(generatePdfPath);
	            	  }
	              } catch (IOException ex) {
	                  ex.printStackTrace();
	              }
	              
	              multipart.addBodyPart(attachPart);
	        }
	        
	        // sets the multi-part as e-mail's content
	        message.setContent(multipart);
	 
	        // sends the e-mail
	       
			try {
				Transport.send(message);
				System.out.println("message sent successfully...");
			}
			catch(Exception e) {
				System.out.println("NETWORK Error");
				System.out.println("Please check your network connection");
			}
		}
		catch(MessagingException e) {
			e.printStackTrace();
		}
	}

}